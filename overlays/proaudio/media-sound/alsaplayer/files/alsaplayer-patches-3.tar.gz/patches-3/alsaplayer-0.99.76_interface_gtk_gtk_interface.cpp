--- alsaplayer-0.99.76.orig/interface/gtk/gtk_interface.cpp
+++ alsaplayer-0.99.76/interface/gtk/gtk_interface.cpp
@@ -25,6 +25,7 @@
 #include <assert.h>
 //#define NEW_SCALE
 //#define SUBSECOND_DISPLAY 
+#include <assert.h>
 
 #include <algorithm>
 #include "utilities.h"
